define([
    'core/js/adapt',
    './dragndropView',
    'core/js/models/questionModel'
], function(Adapt, DragndropView, QuestionModel) {

    var DragndropModel = QuestionModel.extend({
        canSubmit: function () {
            // All droppable slots must be filled (no ui-state-enabled slots remaining)
            var view = this.getQuestionView ? this.getQuestionView() : null;
            if (view) {
                return view.$(".ui-state-enabled").length === 0;
            }
            // Fallback: check _userAnswer — all slots filled means no -1 values
            var userAnswers = this.get("_userAnswer");
            if (!userAnswers || !userAnswers.length) return false;
            return userAnswers.indexOf(-1) === -1;
        }
    });

    return Adapt.register("dragndrop", {
        view: DragndropView,
        model: DragndropModel
    });

});