# adapt-lab-input

An Adapt v5 question component for lab and practical measurement tasks.

The component generates a random set of physical parameters on each session, displays a rich-text task description with the parameters embedded, and asks the student to enter one or more calculated or measured values. Each answer field is checked against a formula-computed correct value with a configurable percentage tolerance.

---

## Features

- **Random parameters** — each parameter is drawn from a numeric range or an explicit value list; the same values are preserved for the entire session and on revisit
- **Formula-computed answers** — correct values are calculated from the generated parameters using safe JavaScript expressions (`vpp / (2 * Math.sqrt(2))`, `1 / frequency * 1000`, etc.)
- **Percentage tolerance** — a global default (e.g. 10%) applies to all fields; individual fields can override it
- **Rich-text body** — `body` and `instruction` are authored in the standard AAT rich-text editor and support full HTML: paragraphs, lists, bold/italic, images, tables
- **Placeholders** — parameter values are embedded in the text via `{{paramName}}` or `{{paramName:2}}` (rounded to 2 decimal places)
- **Multiple answer fields** — each field has its own label, unit, formula, and optional tolerance override
- **Partial scoring** — score = (correct fields) / (total fields) × question weight
- **Model answer** — after all attempts, the student can view the correct computed value for each field
- **No autofill** — input fields use `autocomplete="off"`, `data-form-type="other"`, and related attributes to prevent browser autofill

---

## Installation

Install via the AAT Plugin Manager or copy the `adapt-lab-input` folder into your project's `src/components/` directory, then rebuild.

**Framework requirement:** Adapt `>=5.0.0`

---

## Component JSON structure

```json
{
  "_component": "labInput",
  "_layout": "full",
  "title": "Sine wave measurements",
  "displayTitle": "Sine wave measurements",

  "body": "<p>The signal generator is set to:</p><ul><li>Peak-to-peak voltage: <strong>{{vpp:2}} V</strong></li><li>Frequency: <strong>{{frequency}} Hz</strong></li></ul><p>Connect the oscilloscope and measure the waveform.</p>",

  "instruction": "<p>Enter your measured values below.</p>",

  "_defaultTolerance": 10,

  "_params": [
    { "name": "vpp",       "type": "float", "min": 2.0, "max": 8.0,  "step": 0.5  },
    { "name": "frequency", "type": "int",   "min": 100, "max": 2000, "step": 100  }
  ],

  "_answers": [
    {
      "label":           "RMS amplitude",
      "formula":         "vpp / (2 * Math.sqrt(2))",
      "unit":            "V",
      "placeholder":     "0.000",
      "displayDecimals": 3,
      "tolerance":       10
    },
    {
      "label":           "Period",
      "formula":         "1 / frequency * 1000",
      "unit":            "ms",
      "placeholder":     "0.00",
      "displayDecimals": 2
    }
  ],

  "_attempts": 2,
  "_canShowModelAnswer": true,

  "_feedback": {
    "correct": "Excellent! All measurements are within the acceptable range.",
    "partlyCorrect": {
      "final":    "One value is correct. Check the formula for the other.",
      "notFinal": "One value is off — try again."
    },
    "_incorrect": {
      "final":    "Neither value is in range. Review: RMS = Vpp / (2√2), Period = 1/f.",
      "notFinal": "Both values are outside the acceptable range — try again."
    }
  }
}
```

---

## Field reference

### Top-level fields

| Field | Type | Default | Description |
|---|---|---|---|
| `_defaultTolerance` | number | `10` | Acceptable deviation for all answer fields, in percent |
| `_attempts` | number | `1` | Number of submission attempts |
| `_canShowModelAnswer` | boolean | `true` | Show "correct answer" button after final attempt |

### `_params` items

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | string | ✓ | Identifier used in formulas and placeholders |
| `type` | string | — | `"float"` (default) or `"int"` |
| `min` | number | ✓* | Lower bound of the random range |
| `max` | number | ✓* | Upper bound of the random range |
| `step` | number | — | Quantisation step within the range |
| `values` | array | — | Explicit list of values to pick from; overrides `min`/`max`/`step` |

*Required unless `values` is provided.

### `_answers` items

| Field | Type | Default | Description |
|---|---|---|---|
| `label` | string | — | Field label shown to the student; supports `{{placeholders}}` |
| `formula` | string | ✓ | JS expression for the correct answer; may use any `_params` name and `Math.*` |
| `unit` | string | — | Unit label shown after the input (e.g. `V`, `Hz`, `ms`) |
| `placeholder` | string | — | Input placeholder text |
| `displayDecimals` | number | `3` | Decimal places used when displaying the model answer |
| `tolerance` | number | — | Tolerance % for this field; overrides `_defaultTolerance` if set |

---

## Placeholders

Use `{{name}}` anywhere in `body` or `instruction` (and in answer `label` fields):

| Syntax | Result |
|---|---|
| `{{vpp}}` | Raw generated value |
| `{{vpp:2}}` | Value rounded to 2 decimal places |
| `{{frequency}}` | Integer value |

---

## Formula reference

Formulas are evaluated as JavaScript expressions. All parameter names are available as local variables, and the full `Math` object is accessible.

| Measurement | Formula |
|---|---|
| RMS from peak-to-peak | `vpp / (2 * Math.sqrt(2))` |
| Period (ms) from frequency (Hz) | `1 / frequency * 1000` |
| Voltage divider output | `vin * r2 / (r1 + r2)` |
| Power | `voltage * voltage / resistance` |
| Peak from RMS | `rms * Math.sqrt(2)` |
| Angular frequency | `2 * Math.PI * frequency` |

---

## Scoring

Score = (number of correct fields / total fields) × `_questionWeight`.

A field is correct when:

```
|userValue - correctValue| <= correctValue * (tolerance / 100)
```

Both `.` and `,` are accepted as decimal separators.

---

## Autofill prevention

The input fields include the following attributes to suppress browser autofill and password managers:

```html
autocomplete="off"
autocorrect="off"
autocapitalize="off"
spellcheck="false"
data-form-type="other"
```

---

## File structure

```
adapt-lab-input/
├── js/
│   ├── adapt-lab-input.js   – component registration
│   ├── LabInputModel.js     – param generation, formula eval, scoring
│   └── LabInputView.js      – rendering, input handling, marking
├── less/
│   └── labInput.less        – component styles
├── templates/
│   └── labInput.hbs         – Handlebars template
├── bower.json
├── example.json
├── properties.schema        – AAT editor field definitions
└── README.md
```
