import components from 'core/js/components';
import LabInputModel from './LabInputModel';
import LabInputView from './LabInputView';

export default components.register('labInput', {
  model: LabInputModel,
  view: LabInputView
});
