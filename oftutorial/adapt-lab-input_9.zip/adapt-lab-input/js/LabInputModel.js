import QuestionModel from 'core/js/models/questionModel';

/**
 * LabInputModel
 *
 * A question component for lab measurement tasks.
 *
 * Design notes:
 * - Random parameters are regenerated on every setup (revisit and reset both
 *   produce fresh values, per the configured behaviour).
 * - Parameters AND the formula-computed correct values are produced together in
 *   a single method (`generateSession`) so they can never fall out of sync.
 * - Both are written into model attributes (`_generatedParams`, `_correctValues`)
 *   in one `set()` call, immediately before render, so the template and the
 *   marking logic always read the same values.
 */
export default class LabInputModel extends QuestionModel {

  defaults() {
    return QuestionModel.resultExtend('defaults', {
      _component: 'labInput',
      _supportedLayout: 'full-width',
      _attempts: 1,
      _canShowModelAnswer: true,
      _canShowFeedback: true,
      _canShowMarking: true,

      // Authoring data
      _params: [],
      _answers: [],
      _defaultTolerance: 10,

      // Runtime state (regenerated each setup)
      _generatedParams: {},
      _correctValues: [],
      _userAnswers: []
    });
  }

  init() {
    super.init();
    // Generate parameters and correct values once, when the model is created.
    // This must NOT happen on every render — Submit and Show-Answer trigger
    // re-renders, and regenerating there would desync the displayed task text
    // (rendered from the first generation) from the model's current values.
    this.generateSession();
  }

  // ─── Session generation ─────────────────────────────────────────────────

  generateSession() {
    const params = this._generateParams();
    const correctValues = this._computeCorrectValues(params);

    // Single atomic set — params and correctValues are always consistent
    this.set({
      _generatedParams: params,
      _correctValues: correctValues,
      _userAnswers: []
    });
  }

  _generateParams() {
    const defs = this.get('_params') || [];
    const params = {};
    for (const def of defs) {
      this._validateParamName(def.name);
      params[def.name] = this._generateValue(def);
    }
    return params;
  }

  _validateParamName(name) {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name)) {
      throw new Error(`[labInput] Invalid parameter name "${name}". ` +
        `Names must be valid identifiers: letters, digits, underscores; not starting with a digit.`);
    }
    const reserved = /^(window|document|fetch|eval|Function|require|import|process|global|globalThis|self|top|parent|XMLHttpRequest|setTimeout|setInterval|alert|confirm|prompt)$/;
    if (reserved.test(name)) {
      throw new Error(`[labInput] Parameter name "${name}" shadows a reserved global identifier.`);
    }
  }

  _generateValue(def) {
    const { type = 'float', min, max, step, values } = def;

    // Explicit value list
    if (Array.isArray(values) && values.length) {
      return values[Math.floor(Math.random() * values.length)];
    }

    // Integer range
    if (type === 'int') {
      const lo = Math.ceil(min);
      const hi = Math.floor(max);
      const s = Math.max(1, step || 1);
      const steps = Math.floor((hi - lo) / s) + 1;
      return lo + Math.floor(Math.random() * steps) * s;
    }

    // Float range with step
    if (step) {
      const steps = Math.round((max - min) / step);
      const idx = Math.floor(Math.random() * (steps + 1));
      return Math.round((min + idx * step) * 1e9) / 1e9;
    }

    // Plain float — 3 significant figures
    const raw = min + Math.random() * (max - min);
    return parseFloat(raw.toPrecision(3));
  }

  // ─── Formula evaluation ─────────────────────────────────────────────────

  _computeCorrectValues(params) {
    const answers = this.get('_answers') || [];
    return answers.map(answer => {
      try {
        return this._evalFormula(answer.formula, params);
      } catch (e) {
        console.error(`[labInput] Error in formula "${answer.formula}": ${e.message}`);
        return null;
      }
    });
  }

  _evalFormula(formula, params) {
    if (!formula) throw new Error('Empty formula');

    const reserved = /\b(window|document|fetch|eval|Function|require|import|process|global|globalThis|self|top|parent|XMLHttpRequest|setTimeout|setInterval|alert|confirm|prompt)\b/;
    if (reserved.test(formula)) {
      throw new Error('Unsafe identifier in formula');
    }

    // Declare each parameter as a local variable, then evaluate the expression
    const declarations = Object.entries(params)
      .map(([name, value]) => `var ${name} = ${Number(value)};`)
      .join(' ');

    // eslint-disable-next-line no-new-func
    const fn = new Function(`"use strict"; ${declarations} return (${formula});`);
    const result = fn();

    if (typeof result !== 'number' || !isFinite(result)) {
      throw new Error(`Formula did not return a finite number (got ${result})`);
    }
    return result;
  }

  // ─── Placeholder interpolation ──────────────────────────────────────────
  // Replaces {{name}} or {{name:N}} (N = decimal places) in a template string.

  interpolate(template) {
    if (!template) return '';
    const params = this.get('_generatedParams') || {};
    return template.replace(/\{\{\s*(\w+)\s*(?::(\d+))?\}\}/g, (match, name, decimals) => {
      if (!(name in params)) return match;
      const value = params[name];
      return decimals !== undefined
        ? Number(value).toFixed(parseInt(decimals, 10))
        : String(value);
    });
  }

  // ─── QuestionModel interface ────────────────────────────────────────────

  // Submit enabled only when every field has a non-empty value
  canSubmit() {
    const userAnswers = this.get('_userAnswers') || [];
    const answers = this.get('_answers') || [];
    if (!answers.length) return false;
    return answers.every((_, i) => {
      const v = userAnswers[i];
      return v !== undefined && v !== null && String(v).trim() !== '';
    });
  }

  isCorrect() {
    const results = this.getFieldResults();
    // Empty results must never count as correct ([].every() returns true)
    if (!results.length) return false;
    return results.every(r => r.correct);
  }

  isPartlyCorrect() {
    const results = this.getFieldResults();
    const correctCount = results.filter(r => r.correct).length;
    return correctCount > 0 && correctCount < results.length;
  }

  // Per-field correctness with percentage tolerance
  getFieldResults() {
    const answers = this.get('_answers') || [];
    if (!answers.length) return [];

    let correctValues = this.get('_correctValues') || [];
    // Safety: if correct values are missing (session never generated), generate now
    if (correctValues.length !== answers.length) {
      this.generateSession();
      correctValues = this.get('_correctValues') || [];
    }

    const userAnswers = this.get('_userAnswers') || [];
    const defaultTolerance = this.get('_defaultTolerance') ?? 10;

    return answers.map((answer, i) => {
      const rawInput = String(userAnswers[i] ?? '').replace(',', '.').trim();
      const userVal = parseFloat(rawInput);
      const correctValue = correctValues[i];

      // No input, non-numeric input, or no computable correct value → incorrect
      if (rawInput === '' || isNaN(userVal) || correctValue === null || correctValue === undefined) {
        return { correct: false, userVal, correctValue };
      }

      const tolerancePct = (answer.tolerance !== undefined ? answer.tolerance : defaultTolerance) / 100;
      const allowedDeviation = correctValue !== 0
        ? Math.abs(correctValue) * tolerancePct
        : tolerancePct; // absolute fallback when correct value is exactly 0

      const isWithin = Math.abs(userVal - correctValue) <= allowedDeviation;
      return { correct: isWithin, userVal, correctValue };
    });
  }

  // Score = fraction of correct fields × question weight
  setScore() {
    const results = this.getFieldResults();
    const correctCount = results.filter(r => r.correct).length;
    const total = results.length || 1;
    const weight = this.get('_questionWeight') || 1;
    this.set('_score', (correctCount / total) * weight);
  }

  // User answers are written live by the view; nothing to capture here
  storeUserAnswer() {}

  // Called when the student clicks Reset to make another attempt.
  // This is an ATTEMPT reset — the student stays on the page and re-measures
  // the SAME circuit, so the parameters must NOT change. Only clear the input.
  resetUserAnswer() {
    this.set('_userAnswers', []);
  }

  // Called by Adapt on page revisit when _isResetOnRevisit is enabled.
  // A 'hard' reset means a genuine fresh start (revisit) → regenerate the task.
  // A 'soft' reset preserves more state; we keep parameters in that case.
  reset(type = 'hard', canReset = this.get('_canReset')) {
    const wasReset = super.reset(type, canReset);
    if (!wasReset) return false;
    const isHardReset = (type === 'hard' || type === true);
    if (isHardReset) {
      // Fresh task on genuine revisit
      this.generateSession();
    }
    return true;
  }

  // Correct value formatted for the model-answer display
  getCorrectAnswerForField(index) {
    const correct = (this.get('_correctValues') || [])[index];
    if (correct === null || correct === undefined) return '-';
    const answers = this.get('_answers') || [];
    const decimals = answers[index]?.displayDecimals ?? 3;
    return Number(correct).toFixed(decimals);
  }
}
