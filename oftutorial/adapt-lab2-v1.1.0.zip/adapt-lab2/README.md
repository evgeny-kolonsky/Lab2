# adapt-lab2

## Version history

- **1.1.0** — Input fields (`kind: "input"`) no longer validated: any entered
  number is accepted as correct; `correctValue`/`tolerance` ignored for inputs.
  "Show correct answer" displays the student's own entered value for input fields.
- **1.0.0** — Initial `lab2` (from the working `adapt-lab-input` baseline):
  adds `input`/`computed` field kinds and rich per-field `description`.


An Adapt v5 question component for lab measurement and calculation tasks.

It supports three kinds of values working together:

1. **Random parameters** (`_params`) — generated once per task, shown in the task
   text via `{{name}}` placeholders, available by name inside any formula.

2. **Answer fields** (`_answers`) — shown in one combined list, each with a `kind`:

   - **`kind: "input"`** — a *user variable*. The student types a value (e.g. a
     measured component value). It is validated against a **fixed reference**
     (`correctValue`) with its own tolerance. The entered value is then exposed
     by `name` to later formulas.

   - **`kind: "computed"`** — a *calculated field*. Its reference is computed from
     a `formula` that may use random parameter names AND input-variable names.
     Input-variable names resolve to **what the student actually entered**, so a
     correct calculation from a slightly-off measurement still counts as correct.

This separates two skills: measuring (validity of an `input` field against its
nominal) and calculating (a `computed` field checked against a value derived from
the student's own measurements).

Each field may have a **`description`** — full rich-text HTML shown above the
input, supporting `{{name}}` placeholders for random parameters.

## Worked example — RC filter time constant

- `R` is a random parameter (resistor value on the bench).
- The capacitor is nominally 100 nF. The student measures the real capacitance
  and enters it as an `input` variable `C_measured`, validated against 100 nF ±20%.
- The time constant is a `computed` field: `R * C_measured / 1000000` (ms),
  checked against R times the capacitance **the student entered**, ±10%.

```json
"_params": [
  { "name": "R", "type": "int", "min": 1000, "max": 10000, "step": 500 }
],
"_answers": [
  {
    "kind": "input",
    "name": "C_measured",
    "description": "<p>Measured capacitance</p>",
    "correctValue": 100,
    "tolerance": 20,
    "unit": "nF"
  },
  {
    "kind": "computed",
    "description": "<p>Time constant</p>",
    "formula": "R * C_measured / 1000000",
    "tolerance": 10,
    "unit": "ms",
    "displayDecimals": 4
  }
]
```

## Field reference

### `_params` items

| Field | Type | Description |
|---|---|---|
| `name` | string | Identifier; used in `{{name}}` and in formulas |
| `type` | string | `float` (default) or `int` |
| `min`, `max` | number | Range bounds |
| `step` | number | Optional quantisation step |
| `values` | array | Explicit list; overrides min/max/step |

### `_answers` items

| Field | Applies to | Description |
|---|---|---|
| `kind` | all | `"input"` or `"computed"` (default) |
| `name` | input | Identifier exposing the entered value to formulas (required for input) |
| `correctValue` | input | Fixed reference value to validate against (required for input) |
| `formula` | computed | JS expression over params + input names (required for computed) |
| `description` | all | Rich HTML above the field; supports `{{placeholders}}` |
| `unit` | all | Unit label after the input |
| `placeholder` | all | Placeholder text |
| `displayDecimals` | all | Decimals for the model-answer display (default 3) |
| `tolerance` | all | Tolerance % for this field; overrides `_defaultTolerance` |

## Scoring

Score = (correct fields / total fields) × question weight.

## Tolerance

A field is correct when `|entered - reference| <= |reference| * tolerance%`.
Both `.` and `,` are accepted as decimal separators.

## Lifecycle

- Fresh task generated on first load and on genuine page revisit (hard reset).
- Attempt reset (the Reset button) keeps the same parameters.

## File structure

```
adapt-lab2/
├── js/
│   ├── adapt-lab2.js   – component registration
│   ├── Lab2Model.js    – params, formulas, scope, scoring
│   └── Lab2View.js     – rendering, input handling, marking
├── less/
│   └── lab2.less
├── templates/
│   └── lab2.hbs
├── bower.json
├── example.json
├── properties.schema
└── README.md
```
