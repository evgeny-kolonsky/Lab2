import QuestionView from 'core/js/views/questionView';

export default class Lab2View extends QuestionView {

  events() {
    return {
      'input .js-lab2-answer': 'onInputChange'
    };
  }

  // ─── Setup (runs in preRender, before the template is rendered) ───────────

  setupQuestion() {
    // Do NOT regenerate here — params are generated once in model.init().
    // This method runs on every render (including Submit / Show-Answer), so
    // it only prepares display data from the already-generated values.

    // Interpolated body / instruction (placeholders -> values)
    this.model.set('_interpolatedBody', this.model.interpolate(this.model.get('body')));
    this.model.set('_interpolatedInstruction', this.model.interpolate(this.model.get('instruction')));

    // Answer field display data
    const answers = this.model.get('_answers') || [];
    this.model.set('_answerFields', answers.map((a, i) => ({
      index: i,
      kind: a.kind || 'computed',
      unit: a.unit || '',
      placeholder: a.placeholder || ''
    })));
  }

  // ─── Post-render ──────────────────────────────────────────────────────────

  onQuestionRendered() {
    // Inject interpolated HTML into the placeholders
    this.$('.lab2__body').html(this.model.get('_interpolatedBody'));
    this.$('.lab2__instruction').html(this.model.get('_interpolatedInstruction'));

    // Per-field explanatory HTML (full rich text, interpolated with params)
    const answers = this.model.get('_answers') || [];
    this.$('.js-lab2-description').each((i, el) => {
      const html = this.model.interpolate(answers[i]?.description || answers[i]?.label || '');
      this.$(el).html(html).toggle(!!html.trim());
    });

    this.setReadyStatus();

    // Ensure the Submit button reflects the (empty) initial state
    this.model.checkCanSubmit();

    if (this.model.get('_isSubmitted')) {
      this.restoreUserAnswerView();
      this.showMarking();
    }
  }

  // ─── Input handling ─────────────────────────────────────────────────────

  onInputChange() {
    const userAnswers = [];
    this.$('.js-lab2-answer').each((i, el) => {
      userAnswers[i] = el.value;
    });
    this.model.set('_userAnswers', userAnswers);
    this.model.checkCanSubmit();
  }

  restoreUserAnswerView() {
    const userAnswers = this.model.get('_userAnswers') || [];
    this.$('.js-lab2-answer').each((i, el) => {
      if (userAnswers[i] !== undefined) el.value = userAnswers[i];
    });
  }

  // ─── Marking ──────────────────────────────────────────────────────────────

  showMarking() {
    const results = this.model.getFieldResults();
    this.$('.js-lab2-field').each((i, el) => {
      this.$(el)
        .toggleClass('is-correct', !!results[i]?.correct)
        .toggleClass('is-incorrect', !results[i]?.correct);
    });
  }

  // ─── Model answer ─────────────────────────────────────────────────────────

  showCorrectAnswer() {
    this.$('.js-lab2-answer').each((i, el) => {
      try {
        el.value = this.model.getCorrectAnswerForField(i);
      } catch (e) {
        console.error(`[lab2] could not display correct answer for field ${i}:`, e.message);
        el.value = '-';
      }
      el.disabled = true;
    });
    this.$('.js-lab2-field')
      .removeClass('is-correct is-incorrect')
      .addClass('is-model-answer');
  }

  hideCorrectAnswer() {
    const userAnswers = this.model.get('_userAnswers') || [];
    const isSubmitted = this.model.get('_isSubmitted');
    this.$('.js-lab2-answer').each((i, el) => {
      el.value = userAnswers[i] ?? '';
      el.disabled = !!isSubmitted;
    });
    this.$('.js-lab2-field').removeClass('is-model-answer');
    if (isSubmitted) this.showMarking();
  }

  // ─── Enable / disable ─────────────────────────────────────────────────────

  disableQuestion() {
    this.$('.js-lab2-answer').prop('disabled', true);
  }

  enableQuestion() {
    this.$('.js-lab2-answer').prop('disabled', false);
  }
}
