import components from 'core/js/components';
import Lab2Model from './Lab2Model';
import Lab2View from './Lab2View';

export default components.register('lab2', {
  model: Lab2Model,
  view: Lab2View
});
