define([ "core/js/adapt" ], function(Adapt) {

	function loadScript(scriptObject, callback) {
		var head = document.getElementsByTagName('head')[0];
		var script = document.createElement('script');

		script.type = scriptObject.type || 'text/javascript';

		if (scriptObject.src) {
			script.src = scriptObject.src;
		}

		if (scriptObject.text) {
			script.text = scriptObject.text;
		}

		if (callback) {
			script.onreadystatechange = callback;
			script.onload = callback;
		}

		head.appendChild(script);
	}

	function setUpMathJax() {
		Adapt.wait ? Adapt.wait.begin() : Adapt.trigger("plugin:beginWait");

		var config = Adapt.config.get("_mathJax");
		var inlineConfig = config ? config._inlineConfig : {
				"extensions": [ "tex2jax.js" ],
				"jax": [ "input/TeX", "output/HTML-CSS" ]
		};
		var src = config ? config._src : "//cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.2/MathJax.js?config=TeX-MML-AM_CHTML";

		loadScript({ 
			type: "text/x-mathjax-config",
			text: "MathJax.Hub.Config(" + JSON.stringify(inlineConfig) + ");"
		});

		loadScript({ src: 'assets/mathJaxInit.js' }, function() {
			loadScript({ src: src }, function() {
				Adapt.wait ? Adapt.wait.end() : Adapt.trigger("plugin:endWait");
			});
		});
	}

	function onProcessMath() {
		$(".loading").show();
	}

	function onEndProcess() {
		Adapt.trigger("device:resize");
		$(".loading").hide();
	}

	function onViewReady(view) {
		// view can be a Backbone view object or a DOM element (from popup:opened)
		var el = view && view.el ? view.el : (view instanceof $ ? view[0] : view);

		function checkForMathJax() {
			if (!window.MathJax || !window.MathJax.Hub) {
				window.setTimeout(checkForMathJax, 200);
			} else {
				var Hub = window.MathJax.Hub;
				Hub.Queue([ "Typeset", Hub, el ]);
			}
		}

		$(".loading").show();
		checkForMathJax();
	}

	function onPopupOpened($element) {
		var Hub = window.MathJax.Hub;

		if ($element) $element = $element[0];

		Hub.Queue([ "Typeset", Hub, $element ]);
	}

	Adapt.once("app:dataReady", setUpMathJax).on({
		"mathJax:processMath": onProcessMath,
		"mathJax:endProcess": onEndProcess,
		// Adapt v4 events
		"menuView:ready pageView:ready": onViewReady,
		// Adapt v5 events
		"contentObjectView:ready": onViewReady,
		// Re-typeset after each component renders (React async rendering in v5)
		"view:postRender": onViewReady,
		"popup:opened": onPopupOpened
	});

});
window.MathJax = {
	AuthorInit: function() {
		var Adapt = require("core/js/adapt");
		var messageSet = MathJax.Message.Set;

		MathJax.Message.Set = function(text, n, clearDelay) {
			if (text[0] === "ProcessMath") Adapt.trigger("mathJax:processMath");

			return messageSet.apply(this, arguments);
		};

		MathJax.Hub.Register.MessageHook("End Process", function() {
			Adapt.trigger("mathJax:endProcess");
		});
	}
};
